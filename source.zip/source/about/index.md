---
title: 关于|about me
date: 2018-05-14 15:41:00
type: about
layout: about
---

## 一个有趣的灵魂/about me 

> &nbsp;&nbsp;&nbsp;My name is James Wang(王恒). You can call me James. I was born in 1995.
I am a software engineer, graduated from anhui University Of Science and Technology, and now am employed by Techmax in ShangHai.
Life is colorful, this website was, is and will be the window which used to present the color of my life.
I like programming, reading book, surfing internet, traveling, and I love making friends very much.



## Hello World!
```json
{
  "Name": "王恒（James）",
  "Hobbies": ["Coding", "Photography", "Song","Reading"],
  "Location": "ShangHai China",
  "Company": "Minitab in China",
  "School": "AnHui University",
  "Contacts": {
    "Email": "924114103@qq.com",
    "Weibo": "@adymilk",
    "Github": "https://github.com/adymilk",
    "QQ": "924114103"
  }
}
```


## 本站的小历史

| 时间 | 事件 | 操作 |
| ------------------ | ------- |
| 2015 年 5 月 23日  | 网站第一次上线，这是本站最原始的模型。当初刚刚接触到前端开发的基础，就想着一定要搞出点东西玩玩。带着好奇心我就一些静态页面传到了服务器 | [查看](/) |
| 2016 年 6 月 12日  | 那段时间爱上了谷歌的 Material Design 风格，欲罢不能。风格确实挺好看的 | [查看](/) |
| 2017 年 1 月 8日  | 网站上线了评论功能，访客可以直接通过第三方账号登录评论。RRS订阅功能 | [查看](/) |
| 2018 年 05 月 12 日  | 网站整体网格大改版，由原先的简约紧凑的风格改为视觉性更强，功能更加丰富的展现方式博客后期还会融入更多简单好玩的元素。敬请期待 | [查看](/) |


## 其他
> [申请友情连接点击这里](http://wpa.qq.com/msgrd?v=3&uin=924114103&site=qq&menu=yes)

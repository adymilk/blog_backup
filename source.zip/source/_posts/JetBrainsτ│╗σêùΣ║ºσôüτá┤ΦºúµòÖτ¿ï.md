---
title: JetBrains系列产品破解教程
date: 2016-11-21 16:55:19
tags: JetBrains
categories: 代码笔记
author:
	ncik: 王恒
cover: /img/20180529-2.png
---

JetBrains系列的IDE都非常棒，支持多种插件和主题。深受广大程序员的喜爱。可能有人会说他喜欢用Sublime Text，是因为它的轻便和支持永久试用(相当于免费比如我之前)。
<!-- more -->
但是有的人确实喜欢试用JetBrains系列的软件，因为它的功能强大。但是问题来了，它的系列软件是收费的。如何破呢？本篇文章就是来解决这个问题的！

### 获取注册码
大神搭建的破解服务器地址：http://idea.lanyus.com/
- 点击获取注册码
- 复制注册码后去你的JetBrains软件填写注册码即可成功激活



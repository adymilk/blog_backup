---
title: It's time to unstall your sublime
date: 2017-04-25 16:54:57
tags:
- IDE
- atom
categories: 代码笔记
---
### Atom 更为先进的文本代码编辑器
![atom](/img/aotm.png)
在我没有遇到Atom之前，我一直以为sublime text是最精简强大的代码编辑器。直到Atom的出现，让我彻底改变了这个想法。Atom同样的轻巧，但功能较sublime Text更为强大。如果你也在寻找一款比较喜欢轻便型的IDE，Atom我会马上推荐给你。
<!-- more -->
